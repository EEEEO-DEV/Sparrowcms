<?php
declare(strict_types=1);
namespace Plugins\HelloFooter;
use Sparrow\Core\EventManager;

class HelloFooter
{
    public function register(string $eventManagerClass): void
    {
        $eventManagerClass::addFilter('response_content', function($html){
            return str_replace('Powered by SparrowCMS', 'Powered by SparrowCMS • HelloFooter 插件', (string)$html);
        }, 10);
    }
}
